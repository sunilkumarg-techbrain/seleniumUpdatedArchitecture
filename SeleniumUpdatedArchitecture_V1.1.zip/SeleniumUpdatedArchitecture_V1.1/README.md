# excelseleniumdataprovider
testng data provider using selenium example for google search and return result 
download the project and run 
mvn clean install usign eclipse or in command line 
